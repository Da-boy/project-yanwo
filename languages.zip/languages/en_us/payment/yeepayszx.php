<?php

/**
 * ECSHOP YeePay Epro language file
 * ============================================================================
 * All right reserved (C) 2005-2011 Beijing Yi Shang Interactive Technology
 * Development Ltd.
 * Web site: http://www.ecshop.com
 * ----------------------------------------------------------------------------
 * This is a free/open source software；it mean that you can modify, use and
 * republish the program code, on the premise of that your behavior is not for
 * commercial purposes.
 * ============================================================================
 * @author:     web boy <laupeng@163.com>
 * @version:    v2.1
 * ---------------------------------------------
 */

global $_LANG;

$_LANG['yeepayszx']     = 'YeePay pay shengzhouxing Epro';
$_LANG['ypszx_desc']    = "YeePay Epro shengzhouxing are paid as long as they are issued by China Mobile shengzhouxing can be used to recharge mobile phone card (Please note: The card's serial number to 17, the password for 18), it can be used for online payment, Since the amount of each payment and card shengzhouxing equal, it is recommended the use of Card sales, one-time payment of the amount can not exceed the maximum shengzhouxing card with a face value 300 yuan." .
        '<input type="button" name="Submit" value="Register Now" onclick="window.open(\'https://www.yeepay.com/selfservice/AgentService.action?p0_Cmd=AgentRegister&p1_MerId=10000383855&hmac=bd9e7b0f85bddedb105eebb136632772\')" />';
$_LANG['yp_account'] = 'Merchant Code';
$_LANG['yp_key']     = 'Key businesses';
$_LANG['pay_button'] = 'Immediate payment of the use of YeePay Epro';
?>