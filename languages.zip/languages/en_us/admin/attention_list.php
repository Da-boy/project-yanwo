<?php

/**
 * ECSHOP 程序说明
 * ===========================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ==========================================================
 * $Author: liubo $
 * $Id: attention_list.php 17217 2011-01-19 06:29:08Z liubo $
 */

$_LANG['goods_name'] = 'Trade names';
$_LANG['goods_last_update'] = 'Last updated';
$_LANG['attention_addtolist'] = 'Insert Send Queue';
$_LANG['attention_ckaddtolist'] = 'The concern is determined to send the merchandise merchandise-to-date information? This merchandise would be the latest information sent to users concerned about this merchandise';
$_LANG['pri'][0] = 'Ordinary';
$_LANG['pri'][1] = 'High';
$_LANG['goods_edit'] = 'Editor merchandise';
$_LANG['finish_list'] = 'Has been inserted into %s records, please later ~';
$_LANG['finishing'] = 'Are generated later';
$_LANG['edit_ok'] = 'Operation successful!';
$_LANG['batch_note'] = 'After the date of this update all merchandise insert send queue:';
?>