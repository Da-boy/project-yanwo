<?php

/**
 * ECSHOP 程序說明
 * ===========================================================
 * 版權所有 2005-2011 上海商派網絡科技有限公司，並保留所有權利。
 * 網站地址: http://www.ecshop.com；
 * ----------------------------------------------------------
 * 這不是一個自由軟件！您只能在不用於商業目的的前提下對程序代碼進行修改和
 * 使用；不允許對程序代碼以任何形式任何目的的再發佈。
 * ==========================================================
 * $Author: liubo $
 * $Id: email_list.php 17217 2011-01-19 06:29:08Z liubo $
 */
$_LANG['email_val'] = '郵件地址';
$_LANG['stat']['name'] = '狀態';
$_LANG['stat'][0] = '未確認';
$_LANG['stat'][1] = '已確認';
$_LANG['stat'][2] = '已退訂';
$_LANG['export'] = '導出列表';
$_LANG['id'] = '編號';
$_LANG['button_remove'] = '刪除';
$_LANG['button_unremove'] = '確認';
$_LANG['button_exit'] = '退訂';
$_LANG['no_select_email'] = '沒有選定的Email';
$_LANG['batch_remove_succeed'] = '已成功刪除 %d 個E-mail地址';
$_LANG['batch_unremove_succeed'] = '已成功確認 %d 個E-mail地址';
$_LANG['batch_exit_succeed'] = '已成功退訂 %d 個E-mail地址';
$_LANG['back_list'] = '返回郵件列表';
?>